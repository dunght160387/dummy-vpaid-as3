#!/bin/sh
#
# ./build.sh -d will build the Documentation (docs/index.html)
# ./build.sh -e will build the example SWF (example.swf)
# ./build.sh -s will build the SWC library (IABLib.SWC)
# ./build.sh -des will build all.

NO_ARGS=0
PROG_NAME=$(basename $0)

if [ "$#" -eq "$NO_ARGS" ] 
then
    echo "usage: ./build.sh [-d | -e | -s]"
else
    
    while getopts des OPTION
    do
        case ${OPTION} in
            d) 
                asdoc \
                    -source-path=src \
                    -doc-sources=src/com/hinish/spec \
                    -output=docs
                ;;
            e) 
                mxmlc examples/src/com/hinish/examples/vast/VASTExample1.as \
                    --source-path+=examples/src \
                    --library-path+=examples/libs \
                    -static-link-runtime-shared-libraries \
                    --output=examples/bin/VASTExample1.swf
                
                mxmlc examples/src/com/hinish/examples/vpaid/ExampleAd.as \
                    --source-path+=examples/src \
                    --library-path+=examples/libs \
                    -static-link-runtime-shared-libraries \
                    --output=examples/bin/ExampleAd.swf
                
                mxmlc examples/src/com/hinish/examples/vpaid/Player.as \
                    --source-path+=examples/src \
                    --library-path+=examples/libs \
                    -static-link-runtime-shared-libraries \
                    --output=examples/bin/Player.swf
                ;;
            s) 
                compc \
                    --source-path+=src \
                    --include-sources=src \
                    --output=./bin/IABLib.swc
                ;;
        esac
    done
fi