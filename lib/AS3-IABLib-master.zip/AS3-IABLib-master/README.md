AS3-IABLib
==========

An ActionScript 3 library for IAB specs. Includes the following features: VAST 2.0 Spec (http://www.iab.net/vast) for parsing VAST responses. VPAID Spec (http://www.iab.net/vpaid) for creating VPAID-compliant ads.

There's also a barebones site with several links including a link to the ActionScript documentation: http://nathanhinish.github.com/AS3-IABLib

This software library is distributed under the terms of WTFPL. For more info, please visit http://www.wtfpl.net
